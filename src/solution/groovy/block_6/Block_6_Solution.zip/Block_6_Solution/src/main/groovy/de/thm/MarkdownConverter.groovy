package de.thm

class MarkdownConverter {
    static String convert(String text) {
        def htmlLines = text.readLines().collect { line ->
            if (line.startsWith("### ")) {
                "<h3>${line.substring(4)}</h3>"
            } else if (line.startsWith("## ")) {
                "<h2>${line.substring(3)}</h2>"
            } else if (line.startsWith("# ")) {
                "<h1>${line.substring(2)}</h1>"
            } else if (line.trim()) {
                "<p>${line}</p>"
            } else {
                "" // ignore empty lines
            }
        }.join('\n')

        return "<!DOCTYPE html>\n<html>\n<body>\n${htmlLines}\n</body>\n</html>"
    }

    static void main(String[] args) {
        def inputDir = new File("input")
        def outputDir = new File("output")

        if (!inputDir.exists()) {
            println "Input directory does not exist: $inputDir"
            return
        }

        if (!outputDir.exists()) {
            outputDir.mkdirs()
        }

        def mdFiles = inputDir.listFiles()?.findAll { it.name.endsWith(".md") } ?: []

        if (mdFiles.isEmpty()) {
            println "No Markdown files found in $inputDir"
            return
        }

        mdFiles.each { file ->
            println "Processing ${file.name}..."
            def content = file.text.trim()
            def html = convert(content)
            def outputFile = new File(outputDir, file.name.replaceAll(/\.md$/, ".html"))
            outputFile.text = html
            println "Created ${outputFile.name}"
        }

        println "Conversion finished. ${mdFiles.size()} file(s) processed."
    }
}
